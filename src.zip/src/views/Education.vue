<template>
<div>
    <h1>Education</h1>
    <div class = "row">
        <div class = "col-sm">
            <div class="container" id="leftbox">
                <br>
                <h2 class="a">Bal Bharati Public School Rohini</h2>
                <h3 class="a">Central Board of Secondary Education (10+2)</h3>
                <h3 class="a">April 2004 - March 2018</h3>
                <p> Year 12 Subjects </p>
                <ul>
                    <li>English</li>
                    <li>Physics</li>
                    <li>Chemistry</li>
                    <li>Maths</li>
                    <li>Economics</li>
                </ul>
                <p> Aggregate: 88% </p>
                <a href="https://bbpsrohini.balbharati.org/" target="_blank">School Website</a> 
            </div> 
        </div>

        <div class = "col-sm">
            <div class="container" id="rightbox">
                <br>
                <h2 class="a">Swinburne University of Technology</h2> 
                <h3 class="a">Bachelor of Computer Science</h3>
                <h3 class="a">June 2019 - Present</h3>
                <p>Major: Software Development</p>
                <p>Minors: Statistical Analysis</p>
                <ul>
                    <li>Recipient of Swinburne Excellence Scholarship for 3 semesters</li>
                    <li>Constant Upward growth in results even in conditions of COVID-19</li>
                    <li>Active participation in volunteering and leadership programs</li>
                </ul>
                <br><br>
                <a href="https://bbpsrohini.balbharati.org/" target="_blank">University Website</a>
                <br>
            </div>
        </div>
    </div>
</div>
</template>

