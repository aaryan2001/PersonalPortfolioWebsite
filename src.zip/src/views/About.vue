<template>
	<div>
  <h1>Experience</h1><br>
    <div class="container">
        <br>
        <h2 class="a">FSET Representative at Swinburne Representative Council</h2>
        <h3 class="a">January 2021 - Present</h3>
        <ul>
          <li>Instructing and assisting students with all sorts of problems related to Swinburne's FSET department</li>
          <li>Attend regular meetings with a team and evaluating current affairs such as concerns</li>
          <li>Reviewing ideas introduced by team members</li>
          <li>Setting up agendas for meetings</li>
        </ul>
        <br>
    </div>

    <br>
    <div class="container">
        <br>
        <h2 class="a">Hawthorn Campus Team at Swinburne Student Union</h2>
        <h3 class="a">March 2021 - Present</h3>
        <ul>
          <li>Help students have a say in University</li>
          <li>Help in maintaining the campus and making it a great place for students</li>
        </ul>
        <br>
    </div>

    <br>
    <div class="container">
        <br>
        <h2 class="a">Web developer / App designer at Prodigy Music India</h2>
        <h3 class="a">December 2020 - Present</h3>
        <ul>
          <li>Started as a Developer at a small start-up company in India</li>
          <li>Working on an Ongoing website project</li>
          <li>Collaborated to work out specifics about app company is going to launch soon</li>
        </ul>
        <br>
    </div>

    <br>
    <div class="container">
        <br>
        <h2 class="a">Shift Leader / Cook at Guzman Y Gomez</h2>
        <h3 class="a">November 2019 - Present</h3>
        <ul>
          <li>Managed cash handling and customer interaction</li>
          <li>Assisted in training new staff and help in preparation</li>
        </ul>
        <br>
    </div>
<br>
    <h1>Volunteering and Leadership</h1>
<br>
    <div class="container">
        <br>
        <h2 class="a">Secretary at Swinburne Punjabi Club</h2>
        <h3 class="a">January 2021 - January 2022</h3>
        <br>
    </div>

    <br>
    <div class="container">
        <br>
        <h2 class="a">Web Master at Leo Club</h2>
        <h3 class="a">January 2021 - Present</h3>
        <br>
    </div>

    <br>
    <div class="container">
        <br>
        <h2 class="a">Event’s Organizer at Swinburne Punjabi Club</h2>
        <h3 class="a">January 2020 - January 2021</h3>
        <br>
      </div>
    <br>
  </div>
</template>